export interface AuthPayload {
  phone: string;
  consent: boolean;
  goal: string;
  mode: string;
  tz: string;
  notes?: string;
}

export interface ApiResponse {
  outputs?: Array<{
    outputs?: Array<{
      results?: {
        result?: string;
        message?: {
          data?: { text?: string };
          text?: string;
        };
      };
    }>;
  }>;
  output?: {
    choices?: Array<{
      text?: string;
      message?: { content?: string };
    }>;
  };
}

export interface AssetData {
  [key: string]: number;
}

export interface NetWorthData {
  total: number | null;
  assets: AssetData;
}

export interface DashboardState {
  sid: string;
  auth: boolean;
  phone: string;
  data: { [key: string]: string };
  dark: boolean;
}

export const GOALS = [
  { name: "Overview", goal: "net_worth" },
  { name: "Spend", goal: "spend_summary" },
  { name: "Credit", goal: "credit_health" },
  { name: "EPF", goal: "epf_status" },
  { name: "Mutual Funds", goal: "mf_activity" }
] as const;

export const FLOW_URL = "http://localhost:7860/api/v1/run/2466480e-7072-49a4-ba6f-6f7cd6464c26";
export const DEFAULT_TZ = "Asia/Kolkata";
export const PHONE_REGEX = /^(\+91[-\s]?)?\d{10}$/;
export const SUMMARY_REGEX = /```summary\s*(.*?)\s*```/s;
export const NET_WORTH_REGEX = /Total Net Worth:\s*[₹Rs.\s]*([0-9,]+)/;
export const CREDIT_SCORE_REGEX = /Credit Score:\s*([0-9]{3})/;
