import React, { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { callMoneyMate, extractSummary } from '@/lib/moneymate-api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Loader2, RefreshCw, TrendingUp, TrendingDown, DollarSign, Target, Calendar, BarChart3, PieChart as PieChartIcon, Activity } from 'lucide-react';
import { DEFAULT_TZ } from '@shared/moneymate';

export default function MutualFunds() {
  const { state, dispatch } = useDashboard();
  const [loading, setLoading] = useState(false);

  const refreshMFData = async () => {
    setLoading(true);
    try {
      const response = await callMoneyMate({
        phone: state.phone,
        consent: true,
        goal: 'mf_activity',
        mode: 'data_only',
        tz: DEFAULT_TZ
      }, state.sid);
      
      const summary = extractSummary(response);
      dispatch({ type: 'SET_DATA', payload: { mf_activity: summary } });
    } catch (error) {
      console.error('Failed to refresh MF data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Mock mutual fund data
  const portfolio = [
    {
      id: 1,
      name: 'HDFC Top 100 Fund',
      category: 'Large Cap',
      invested: 250000,
      current: 285000,
      units: 3250,
      nav: 87.69,
      returns: 14.0,
      sipAmount: 5000,
      sipDate: 10,
      status: 'Active'
    },
    {
      id: 2,
      name: 'ICICI Prudential Bluechip Fund',
      category: 'Large Cap',
      invested: 180000,
      current: 198000,
      units: 2890,
      nav: 68.51,
      returns: 10.0,
      sipAmount: 3000,
      sipDate: 5,
      status: 'Active'
    },
    {
      id: 3,
      name: 'Axis Small Cap Fund',
      category: 'Small Cap',
      invested: 150000,
      current: 195000,
      units: 2150,
      nav: 90.70,
      returns: 30.0,
      sipAmount: 2500,
      sipDate: 15,
      status: 'Active'
    },
    {
      id: 4,
      name: 'SBI Equity Hybrid Fund',
      category: 'Hybrid',
      invested: 100000,
      current: 112000,
      units: 4200,
      nav: 26.67,
      returns: 12.0,
      sipAmount: 2000,
      sipDate: 20,
      status: 'Active'
    }
  ];

  const totalInvested = portfolio.reduce((sum, fund) => sum + fund.invested, 0);
  const totalCurrent = portfolio.reduce((sum, fund) => sum + fund.current, 0);
  const totalGains = totalCurrent - totalInvested;
  const totalReturns = ((totalGains / totalInvested) * 100);

  // Performance history data
  const performanceData = [
    { month: 'Jul 23', value: 580000 },
    { month: 'Aug 23', value: 598000 },
    { month: 'Sep 23', value: 585000 },
    { month: 'Oct 23', value: 612000 },
    { month: 'Nov 23', value: 635000 },
    { month: 'Dec 23', value: 652000 },
    { month: 'Jan 24', value: 679000 },
    { month: 'Feb 24', value: 695000 },
    { month: 'Mar 24', value: 715000 },
    { month: 'Apr 24', value: 742000 },
    { month: 'May 24', value: 768000 },
    { month: 'Jun 24', value: totalCurrent }
  ];

  // Asset allocation data
  const allocationData = [
    { name: 'Large Cap', value: 68.7, amount: 483000, color: '#10B981' },
    { name: 'Small Cap', value: 22.1, amount: 195000, color: '#3B82F6' },
    { name: 'Hybrid', value: 12.7, amount: 112000, color: '#F59E0B' }
  ];

  // SIP calendar data
  const sipSchedule = [
    { date: '05 Feb', fund: 'ICICI Prudential Bluechip', amount: 3000, status: 'completed' },
    { date: '10 Feb', fund: 'HDFC Top 100', amount: 5000, status: 'completed' },
    { date: '15 Feb', fund: 'Axis Small Cap', amount: 2500, status: 'completed' },
    { date: '20 Feb', fund: 'SBI Equity Hybrid', amount: 2000, status: 'completed' },
    { date: '05 Mar', fund: 'ICICI Prudential Bluechip', amount: 3000, status: 'upcoming' },
    { date: '10 Mar', fund: 'HDFC Top 100', amount: 5000, status: 'upcoming' }
  ];

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;
  const formatPercentage = (value: number) => `${value > 0 ? '+' : ''}${value.toFixed(1)}%`;

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <TrendingUp className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Mutual Funds Portfolio</h1>
            <p className="text-muted-foreground">Track your investments, SIPs, and performance analytics</p>
          </div>
        </div>
        <Button onClick={refreshMFData} disabled={loading} variant="outline">
          {loading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="mr-2 h-4 w-4" />
          )}
          Refresh Data
        </Button>
      </div>

      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Invested</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalInvested)}</div>
            <p className="text-xs text-muted-foreground">Across {portfolio.length} funds</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalCurrent)}</div>
            <p className="text-xs text-success">
              {formatPercentage(totalReturns)} overall returns
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Gains</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">{formatCurrency(totalGains)}</div>
            <p className="text-xs text-muted-foreground">Unrealized gains</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly SIP</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(portfolio.reduce((sum, fund) => sum + fund.sipAmount, 0))}
            </div>
            <p className="text-xs text-muted-foreground">Auto-invested monthly</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="portfolio" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="sip">SIP Tracker</TabsTrigger>
          <TabsTrigger value="allocation">Allocation</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="portfolio" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Fund Holdings</CardTitle>
              <CardDescription>Detailed view of all your mutual fund investments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {portfolio.map((fund) => {
                  const gain = fund.current - fund.invested;
                  const returnPercentage = ((gain / fund.invested) * 100);
                  
                  return (
                    <div key={fund.id} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3">
                            <div>
                              <h4 className="font-medium">{fund.name}</h4>
                              <div className="flex items-center space-x-2 mt-1">
                                <Badge variant="outline">{fund.category}</Badge>
                                <Badge variant={fund.status === 'Active' ? 'default' : 'secondary'}>
                                  {fund.status}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-semibold">{formatCurrency(fund.current)}</p>
                          <div className={`flex items-center justify-end space-x-1 ${
                            gain >= 0 ? 'text-success' : 'text-destructive'
                          }`}>
                            {gain >= 0 ? (
                              <TrendingUp className="w-4 h-4" />
                            ) : (
                              <TrendingDown className="w-4 h-4" />
                            )}
                            <span className="text-sm font-medium">
                              {formatCurrency(gain)} ({formatPercentage(returnPercentage)})
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Invested</p>
                          <p className="font-medium">{formatCurrency(fund.invested)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Units</p>
                          <p className="font-medium">{fund.units.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">NAV</p>
                          <p className="font-medium">₹{fund.nav}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">SIP Amount</p>
                          <p className="font-medium">{formatCurrency(fund.sipAmount)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">SIP Date</p>
                          <p className="font-medium">{fund.sipDate}th</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="w-5 h-5" />
                <span>Portfolio Performance</span>
              </CardTitle>
              <CardDescription>Portfolio value growth over the last 12 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="month" 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickFormatter={(value) => `₹${(value / 100000).toFixed(0)}L`}
                    />
                    <Tooltip 
                      formatter={(value: number) => [`₹${value.toLocaleString('en-IN')}`, 'Portfolio Value']}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      fill="hsl(var(--primary))"
                      fillOpacity={0.1}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {portfolio.map((fund) => (
              <Card key={fund.id}>
                <CardHeader>
                  <CardTitle className="text-base">{fund.name}</CardTitle>
                  <CardDescription>{fund.category}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">1Y Returns</span>
                      <span className={`text-sm font-medium ${
                        fund.returns >= 0 ? 'text-success' : 'text-destructive'
                      }`}>
                        {formatPercentage(fund.returns)}
                      </span>
                    </div>
                    <Progress value={Math.min(fund.returns, 50)} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="sip" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>SIP Schedule</span>
              </CardTitle>
              <CardDescription>Upcoming and recent SIP transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {sipSchedule.map((sip, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        sip.status === 'completed' ? 'bg-success' : 'bg-warning'
                      }`}></div>
                      <div>
                        <p className="font-medium">{sip.fund}</p>
                        <p className="text-sm text-muted-foreground">{sip.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{formatCurrency(sip.amount)}</p>
                      <Badge variant={sip.status === 'completed' ? 'default' : 'secondary'}>
                        {sip.status === 'completed' ? 'Completed' : 'Upcoming'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>SIP Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Monthly SIP</span>
                    <span className="font-medium">
                      {formatCurrency(portfolio.reduce((sum, fund) => sum + fund.sipAmount, 0))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Annual Investment</span>
                    <span className="font-medium">
                      {formatCurrency(portfolio.reduce((sum, fund) => sum + fund.sipAmount, 0) * 12)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Active SIPs</span>
                    <span className="font-medium">{portfolio.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Next SIP Date</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-2xl font-bold mb-2">05 Mar 2024</div>
                  <p className="text-muted-foreground mb-4">ICICI Prudential Bluechip Fund</p>
                  <Badge variant="outline">₹3,000</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="allocation" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <PieChartIcon className="w-5 h-5" />
                  <span>Asset Allocation</span>
                </CardTitle>
                <CardDescription>Distribution across fund categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={allocationData}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        dataKey="value"
                        label={({ name, value }) => `${name} (${value.toFixed(1)}%)`}
                      >
                        {allocationData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: number, name: string, props: any) => [
                          `${value.toFixed(1)}%`, 
                          `${formatCurrency(props.payload.amount)}`
                        ]}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Allocation Breakdown</CardTitle>
                <CardDescription>Detailed category-wise distribution</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allocationData.map((category, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-2">
                        <span className="font-medium">{category.name}</span>
                        <span className="text-muted-foreground">{category.value.toFixed(1)}%</span>
                      </div>
                      <Progress value={category.value} className="h-2 mb-1" />
                      <p className="text-sm text-muted-foreground">{formatCurrency(category.amount)}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5" />
                  <span>Portfolio Metrics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">XIRR (Annualized)</p>
                    <p className="text-lg font-semibold text-success">+15.2%</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Best Performer</p>
                    <p className="text-lg font-semibold">Axis Small Cap</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Avg. Portfolio Age</p>
                    <p className="text-lg font-semibold">2.3 years</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Portfolio Risk</p>
                    <div className="flex items-center space-x-2">
                      <Progress value={65} className="flex-1 h-2" />
                      <span className="text-sm font-medium">Moderate</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Diversification Score</p>
                    <div className="flex items-center space-x-2">
                      <Progress value={78} className="flex-1 h-2" />
                      <span className="text-sm font-medium">Good</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium">Rebalance Portfolio</p>
                    <p className="text-xs text-muted-foreground">Consider adding mid-cap exposure</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium">Tax Optimization</p>
                    <p className="text-xs text-muted-foreground">ELSS funds for 80C benefits</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Raw Data */}
      {state.data.mf_activity && (
        <Card>
          <CardHeader>
            <CardTitle>Mutual Fund Activity Data</CardTitle>
            <CardDescription>Raw data from your fund transactions</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="text-sm bg-muted p-4 rounded-md overflow-auto max-h-64">
              {state.data.mf_activity}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
