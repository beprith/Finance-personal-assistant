import React, { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { callMoneyMate, extractSummary } from '@/lib/moneymate-api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, Send, MessageCircle } from 'lucide-react';
import { DEFAULT_TZ } from '@shared/moneymate';

export default function Chat() {
  const { state } = useDashboard();
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    setLoading(true);
    try {
      const chatResponse = await callMoneyMate({
        phone: state.phone,
        consent: true,
        goal: 'custom',
        mode: 'summary',
        tz: DEFAULT_TZ,
        notes: question
      }, state.sid);
      
      const summary = extractSummary(chatResponse);
      setResponse(summary);
      setQuestion('');
    } catch (error) {
      setResponse('Sorry, I encountered an error processing your question. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <MessageCircle className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold text-foreground">Chat with MoneyMate</h1>
          <p className="text-muted-foreground">Ask questions about your finances and get personalized insights</p>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ask MoneyMate</CardTitle>
            <CardDescription>Get personalized financial advice and insights</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                placeholder="Ask anything about your finances..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                disabled={loading}
              />
              <Button type="submit" disabled={loading || !question.trim()} className="w-full">
                {loading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Send className="mr-2 h-4 w-4" />
                )}
                {loading ? 'Thinking...' : 'Ask MoneyMate'}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Response</CardTitle>
            <CardDescription>MoneyMate's insights and recommendations</CardDescription>
          </CardHeader>
          <CardContent>
            {response ? (
              <div className="bg-muted p-4 rounded-md">
                <p className="text-sm whitespace-pre-wrap">{response}</p>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Ask a question to get started</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Example Questions */}
      <Card>
        <CardHeader>
          <CardTitle>Example Questions</CardTitle>
          <CardDescription>Try asking MoneyMate about these topics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              "What's my current financial health?",
              "How can I improve my credit score?",
              "Should I increase my SIP investments?",
              "What are my biggest spending categories?",
              "How is my EPF performing?",
              "What investments should I consider?"
            ].map((example, index) => (
              <Button
                key={index}
                variant="outline"
                className="text-left justify-start h-auto p-4"
                onClick={() => setQuestion(example)}
                disabled={loading}
              >
                {example}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
