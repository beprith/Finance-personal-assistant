import React, { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { parseNetWorth, projectSIP } from '@/lib/moneymate-api';
import { ProjectionChart } from '@/components/charts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Calculator, TrendingUp, Target, DollarSign } from 'lucide-react';

export default function WhatIf() {
  const { state } = useDashboard();
  const [extraSip, setExtraSip] = useState([3000]);
  const [years, setYears] = useState([5]);

  const netWorthData = parseNetWorth(state.data.net_worth || '');
  const currentNetWorth = netWorthData.total || 0;
  
  const projectedValue = projectSIP(currentNetWorth, extraSip[0], years[0]);
  const totalInvestment = extraSip[0] * 12 * years[0];
  const gains = projectedValue - currentNetWorth - totalInvestment;
  const returnRate = totalInvestment > 0 ? ((gains / totalInvestment) * 100) : 0;

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;

  const scenarios = [
    { sip: 1000, years: 5, color: 'bg-blue-100 text-blue-800' },
    { sip: 3000, years: 5, color: 'bg-green-100 text-green-800' },
    { sip: 5000, years: 5, color: 'bg-purple-100 text-purple-800' },
    { sip: extraSip[0], years: 10, color: 'bg-orange-100 text-orange-800' },
  ];

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <Calculator className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold text-foreground">What-If Analysis</h1>
          <p className="text-muted-foreground">Explore different investment scenarios and their potential outcomes</p>
        </div>
      </div>

      {/* Current Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5" />
            <span>Current Financial Position</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Current Net Worth</p>
              <p className="text-2xl font-bold text-foreground">{formatCurrency(currentNetWorth)}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Assets Tracked</p>
              <p className="text-2xl font-bold text-foreground">{Object.keys(netWorthData.assets).length}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Status</p>
              <Badge variant="default" className="text-sm">Active Investor</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Investment Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Investment Parameters</CardTitle>
            <CardDescription>Adjust your investment scenario</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex justify-between mb-2">
                <label className="text-sm font-medium">Extra SIP per month</label>
                <span className="text-sm text-muted-foreground">{formatCurrency(extraSip[0])}</span>
              </div>
              <Slider
                value={extraSip}
                onValueChange={setExtraSip}
                max={20000}
                step={500}
                className="w-full"
              />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <label className="text-sm font-medium">Investment Duration</label>
                <span className="text-sm text-muted-foreground">{years[0]} years</span>
              </div>
              <Slider
                value={years}
                onValueChange={setYears}
                min={1}
                max={15}
                step={1}
                className="w-full"
              />
            </div>

            <div className="pt-4 space-y-3 border-t">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Total Investment</span>
                <span className="text-sm font-medium">{formatCurrency(totalInvestment)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Expected Gains</span>
                <span className="text-sm font-medium text-success">{formatCurrency(gains)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Return Rate</span>
                <span className="text-sm font-medium">{returnRate.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between pt-2 border-t">
                <span className="font-medium">Future Net Worth</span>
                <span className="text-lg font-bold text-success">{formatCurrency(projectedValue)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5" />
              <span>Growth Projection</span>
            </CardTitle>
            <CardDescription>Assuming 8% annual returns (CAGR)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center p-6 bg-primary/5 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Projected Net Worth in {years[0]} years</p>
                <p className="text-3xl font-bold text-primary">{formatCurrency(projectedValue)}</p>
                <p className="text-sm text-success mt-2">
                  <TrendingUp className="w-4 h-4 inline mr-1" />
                  {((projectedValue / currentNetWorth - 1) * 100).toFixed(1)}% growth
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Key Assumptions:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• 8% annual returns (CAGR)</li>
                  <li>• Monthly SIP investments</li>
                  <li>• Compound growth calculated annually</li>
                  <li>• No intermediate withdrawals</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart Visualization */}
      <ProjectionChart
        currentValue={currentNetWorth}
        projectedValue={projectedValue}
        years={years[0]}
        extraSip={extraSip[0]}
      />

      {/* Quick Scenarios */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Scenarios</CardTitle>
          <CardDescription>Compare different investment approaches</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {scenarios.map((scenario, index) => {
              const projected = projectSIP(currentNetWorth, scenario.sip, scenario.years);
              const investment = scenario.sip * 12 * scenario.years;
              const growth = projected - currentNetWorth - investment;
              
              return (
                <div key={index} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <Badge className={scenario.color}>
                      ₹{scenario.sip}/month
                    </Badge>
                    <span className="text-sm text-muted-foreground">{scenario.years} years</span>
                  </div>
                  <p className="text-lg font-semibold">{formatCurrency(projected)}</p>
                  <p className="text-sm text-success">+{formatCurrency(growth)}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
