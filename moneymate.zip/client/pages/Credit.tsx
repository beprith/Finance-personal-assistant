import React, { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { callMoneyMate, extractSummary, parseCreditScore } from '@/lib/moneymate-api';
import { CreditGauge } from '@/components/charts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, RefreshCw, CreditCard, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, XCircle, Clock, Shield, Target } from 'lucide-react';
import { DEFAULT_TZ } from '@shared/moneymate';

export default function Credit() {
  const { state, dispatch } = useDashboard();
  const [loading, setLoading] = useState(false);

  const creditScore = parseCreditScore(state.data.credit_health || '');

  // Debug credit health data and manual score extraction
  const [manualCreditScore, setManualCreditScore] = React.useState<number | null>(null);

  React.useEffect(() => {
    if (state.data.credit_health) {
      console.log('💳 Credit Page - Raw credit health data:', state.data.credit_health);
      console.log('📊 Credit Page - Parsed credit score:', creditScore);

      // Manual extraction - look for any 3-digit number that could be a credit score
      const allNumbers = state.data.credit_health.match(/\b\d{3}\b/g);
      if (allNumbers) {
        console.log('🔢 Found 3-digit numbers:', allNumbers);
        // Find the first number in credit score range (300-900)
        const validScore = allNumbers
          .map(num => parseInt(num))
          .find(num => num >= 300 && num <= 900);
        if (validScore) {
          console.log('✅ Manual extraction found credit score:', validScore);
          setManualCreditScore(validScore);
        }
      }
    }
  }, [state.data.credit_health, creditScore]);

  const refreshCreditData = async () => {
    setLoading(true);
    try {
      const response = await callMoneyMate({
        phone: state.phone,
        consent: true,
        goal: 'credit_health',
        mode: 'data_only',
        tz: DEFAULT_TZ
      }, state.sid);
      
      const summary = extractSummary(response);
      dispatch({ type: 'SET_DATA', payload: { credit_health: summary } });
    } catch (error) {
      console.error('Failed to refresh credit data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCreditRating = (score: number | null) => {
    if (!score) return { rating: 'Unknown', color: 'bg-gray-500' };
    if (score >= 800) return { rating: 'Excellent', color: 'bg-green-600' };
    if (score >= 750) return { rating: 'Very Good', color: 'bg-green-500' };
    if (score >= 700) return { rating: 'Good', color: 'bg-blue-500' };
    if (score >= 650) return { rating: 'Fair', color: 'bg-yellow-500' };
    return { rating: 'Poor', color: 'bg-red-500' };
  };

  const getCreditUtilization = () => Math.floor(Math.random() * 40) + 10; // Mock data
  const getPaymentHistory = () => Math.floor(Math.random() * 15) + 85; // Mock data
  const getCreditAge = () => Math.floor(Math.random() * 5) + 3; // Mock data

  const creditUtilization = getCreditUtilization();
  const paymentHistory = getPaymentHistory();
  const creditAge = getCreditAge();
  // Use manual score as fallback if parsing failed
  const displayCreditScore = creditScore || manualCreditScore;
  const { rating, color } = getCreditRating(displayCreditScore);

  // Mock credit report data
  const creditAccounts = [
    { bank: 'HDFC Bank', type: 'Credit Card', limit: 200000, used: 45000, status: 'Active', lastPayment: '2024-01-15' },
    { bank: 'ICICI Bank', type: 'Personal Loan', limit: 500000, used: 500000, status: 'Active', lastPayment: '2024-01-10' },
    { bank: 'SBI', type: 'Credit Card', limit: 150000, used: 12000, status: 'Active', lastPayment: '2024-01-12' },
    { bank: 'Axis Bank', type: 'Auto Loan', limit: 800000, used: 350000, status: 'Active', lastPayment: '2024-01-08' }
  ];

  const creditHistory = [
    { month: 'Jan 2024', score: creditScore || 750, change: '+5' },
    { month: 'Dec 2023', score: (creditScore || 750) - 5, change: '+12' },
    { month: 'Nov 2023', score: (creditScore || 750) - 17, change: '-8' },
    { month: 'Oct 2023', score: (creditScore || 750) - 9, change: '+15' },
    { month: 'Sep 2023', score: (creditScore || 750) - 24, change: '+3' },
    { month: 'Aug 2023', score: (creditScore || 750) - 27, change: '+7' }
  ];

  const creditTips = [
    { 
      icon: <CheckCircle className="w-5 h-5 text-success" />,
      title: "Pay Bills on Time",
      description: "Set up automatic payments for all credit accounts",
      impact: "High Impact",
      difficulty: "Easy"
    },
    { 
      icon: <Target className="w-5 h-5 text-info" />,
      title: "Keep Credit Utilization Low",
      description: "Maintain usage below 30% of your credit limit",
      impact: "High Impact",
      difficulty: "Medium"
    },
    { 
      icon: <Shield className="w-5 h-5 text-warning" />,
      title: "Monitor Your Credit Report",
      description: "Check for errors and dispute inaccuracies promptly",
      impact: "Medium Impact",
      difficulty: "Easy"
    },
    { 
      icon: <Clock className="w-5 h-5 text-info" />,
      title: "Build Credit History",
      description: "Keep old accounts open to maintain credit age",
      impact: "Medium Impact",
      difficulty: "Easy"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <CreditCard className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Credit Health Report</h1>
            <p className="text-muted-foreground">Complete analysis of your credit profile and recommendations</p>
          </div>
        </div>
        <Button onClick={refreshCreditData} disabled={loading} variant="outline">
          {loading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="mr-2 h-4 w-4" />
          )}
          Refresh Data
        </Button>
      </div>

      {/* Credit Score Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Credit Score
              <Badge className={color}>{rating}</Badge>
            </CardTitle>
            <CardDescription>Current creditworthiness rating</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">{displayCreditScore || '—'}</div>
              <div className="text-sm text-muted-foreground mb-4">Out of 900</div>
              {displayCreditScore && (
                <div className="flex items-center justify-center space-x-1">
                  {displayCreditScore >= 750 ? (
                    <TrendingUp className="w-4 h-4 text-success" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-destructive" />
                  )}
                  <span className={`text-sm ${displayCreditScore >= 750 ? 'text-success' : 'text-destructive'}`}>
                    {displayCreditScore >= 750 ? 'Excellent Range' : 'Room for Improvement'}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Credit Score Factors</CardTitle>
            <CardDescription>Key metrics affecting your credit score</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Payment History</span>
                <span className="text-sm text-muted-foreground">{paymentHistory}%</span>
              </div>
              <Progress value={paymentHistory} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">35% of your credit score</p>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Credit Utilization</span>
                <span className="text-sm text-muted-foreground">{creditUtilization}%</span>
              </div>
              <Progress value={creditUtilization} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">30% of your credit score</p>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Credit History Length</span>
                <span className="text-sm text-muted-foreground">{creditAge} years</span>
              </div>
              <Progress value={(creditAge / 10) * 100} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">15% of your credit score</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      {displayCreditScore && displayCreditScore < 650 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Your credit score is below the recommended threshold. Consider following our improvement tips below.
          </AlertDescription>
        </Alert>
      )}

      {creditUtilization > 30 && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Your credit utilization is above 30%. Consider paying down balances to improve your score.
          </AlertDescription>
        </Alert>
      )}

      {/* Detailed Analysis */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="accounts">Accounts</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="tips">Improvement Tips</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {displayCreditScore ? (
              <CreditGauge score={displayCreditScore} />
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <p className="text-muted-foreground mb-4">No credit score data available</p>
                  <Button onClick={refreshCreditData} disabled={loading}>
                    Load Credit Data
                  </Button>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Credit Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Credit Limit</p>
                    <p className="text-lg font-semibold">₹16,50,000</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Used</p>
                    <p className="text-lg font-semibold">₹9,07,000</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Available Credit</p>
                    <p className="text-lg font-semibold text-success">₹7,43,000</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Active Accounts</p>
                    <p className="text-lg font-semibold">{creditAccounts.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Credit Accounts</CardTitle>
              <CardDescription>Overview of all your credit accounts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {creditAccounts.map((account, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <div>
                          <h4 className="font-medium">{account.bank}</h4>
                          <p className="text-sm text-muted-foreground">{account.type}</p>
                        </div>
                        <Badge variant={account.status === 'Active' ? 'default' : 'secondary'}>
                          {account.status}
                        </Badge>
                      </div>
                      <div className="mt-2 grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Limit/Amount</p>
                          <p className="font-medium">₹{account.limit.toLocaleString('en-IN')}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Used/Outstanding</p>
                          <p className="font-medium">₹{account.used.toLocaleString('en-IN')}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Last Payment</p>
                          <p className="font-medium">{account.lastPayment}</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Utilization</p>
                      <p className="font-medium">
                        {account.type.includes('Loan') ? 'Outstanding' : `${Math.round((account.used / account.limit) * 100)}%`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Credit Score History</CardTitle>
              <CardDescription>Your credit score trend over the last 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {creditHistory.map((entry, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{entry.month}</p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-lg font-semibold">{entry.score}</p>
                      </div>
                      <div className={`flex items-center space-x-1 ${
                        entry.change.startsWith('+') ? 'text-success' : 'text-destructive'
                      }`}>
                        {entry.change.startsWith('+') ? (
                          <TrendingUp className="w-4 h-4" />
                        ) : (
                          <TrendingDown className="w-4 h-4" />
                        )}
                        <span className="text-sm font-medium">{entry.change}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tips" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {creditTips.map((tip, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    {tip.icon}
                    <span>{tip.title}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{tip.description}</p>
                  <div className="flex justify-between">
                    <Badge variant="outline">{tip.impact}</Badge>
                    <Badge variant="secondary">{tip.difficulty}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Raw Data */}
      {state.data.credit_health && (
        <Card>
          <CardHeader>
            <CardTitle>Raw Credit Health Data</CardTitle>
            <CardDescription>Detailed information from your credit report</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="text-sm bg-muted p-4 rounded-md overflow-auto max-h-64">
              {state.data.credit_health}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
