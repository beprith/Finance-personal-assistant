import React, { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { callMoneyMate, extractSummary } from '@/lib/moneymate-api';
import { SpendLineChart, CategoryHeatmap } from '@/components/charts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, RefreshCw, Wallet } from 'lucide-react';
import { DEFAULT_TZ } from '@shared/moneymate';

export default function Spend() {
  const { state, dispatch } = useDashboard();
  const [loading, setLoading] = useState(false);

  const refreshSpendData = async () => {
    setLoading(true);
    try {
      const response = await callMoneyMate({
        phone: state.phone,
        consent: true,
        goal: 'spend_summary',
        mode: 'data_only',
        tz: DEFAULT_TZ
      }, state.sid);
      
      const summary = extractSummary(response);
      dispatch({ type: 'SET_DATA', payload: { spend_summary: summary } });
    } catch (error) {
      console.error('Failed to refresh spend data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Mock data for demonstration
  const mockSpendData = [
    { month: 'Jan 2024', amount: 45000 },
    { month: 'Feb 2024', amount: 52000 },
    { month: 'Mar 2024', amount: 48000 },
    { month: 'Apr 2024', amount: 55000 },
    { month: 'May 2024', amount: 49000 },
    { month: 'Jun 2024', amount: 51000 }
  ];

  const mockCategoryData = [
    { category: 'Food & Dining', amount: 15000, percentage: 29.4 },
    { category: 'Transportation', amount: 12000, percentage: 23.5 },
    { category: 'Shopping', amount: 8000, percentage: 15.7 },
    { category: 'Entertainment', amount: 6000, percentage: 11.8 },
    { category: 'Utilities', amount: 5000, percentage: 9.8 },
    { category: 'Healthcare', amount: 5000, percentage: 9.8 }
  ];

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Wallet className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Spending Analysis</h1>
            <p className="text-muted-foreground">Track and analyze your spending patterns</p>
          </div>
        </div>
        <Button onClick={refreshSpendData} disabled={loading} variant="outline">
          {loading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="mr-2 h-4 w-4" />
          )}
          Refresh Data
        </Button>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SpendLineChart data={mockSpendData} />
        <CategoryHeatmap data={mockCategoryData} />
      </div>

      {/* Raw Data */}
      {state.data.spend_summary && (
        <Card>
          <CardHeader>
            <CardTitle>Spending Summary Data</CardTitle>
            <CardDescription>Raw data from your financial accounts</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="text-sm bg-muted p-4 rounded-md overflow-auto max-h-64">
              {state.data.spend_summary}
            </pre>
          </CardContent>
        </Card>
      )}

      {!state.data.spend_summary && (
        <Card>
          <CardContent className="text-center py-12">
            <p className="text-muted-foreground mb-4">No spending data available</p>
            <Button onClick={refreshSpendData} disabled={loading}>
              Load Spending Data
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
