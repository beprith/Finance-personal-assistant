import React, { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { callMoneyMate, extractSummary } from '@/lib/moneymate-api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Loader2, RefreshCw, PiggyBank, TrendingUp, Calculator, Calendar, Building, User, Gift, Target, Banknote, FileText } from 'lucide-react';
import { DEFAULT_TZ } from '@shared/moneymate';

export default function EPF() {
  const { state, dispatch } = useDashboard();
  const [loading, setLoading] = useState(false);

  const refreshEPFData = async () => {
    setLoading(true);
    try {
      const response = await callMoneyMate({
        phone: state.phone,
        consent: true,
        goal: 'epf_status',
        mode: 'data_only',
        tz: DEFAULT_TZ
      }, state.sid);
      
      const summary = extractSummary(response);
      dispatch({ type: 'SET_DATA', payload: { epf_status: summary } });
    } catch (error) {
      console.error('Failed to refresh EPF data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Mock EPF data - Replace with actual API data parsing
  const epfData = {
    accountNumber: 'DL/12345/1234567890',
    currentBalance: 850000,
    employeeContribution: 450000,
    employerContribution: 400000,
    totalContributions: 850000,
    interestEarned: 85000,
    currentRate: 8.15,
    memberSince: '2018-04-01',
    lastContribution: '2024-01-31',
    monthlyContribution: 3600,
    basicSalary: 30000,
    contributionRate: 12,
    pensionFund: 127500, // 8.33% portion
    epfFund: 722500,     // 3.67% portion
    vpcContribution: 0,   // Voluntary Provident Fund
    status: 'Active'
  };

  // Contribution history for the last 12 months
  const contributionHistory = [
    { month: 'Feb 23', employee: 3600, employer: 3600, interest: 580, total: 7780 },
    { month: 'Mar 23', employee: 3600, employer: 3600, interest: 595, total: 7795 },
    { month: 'Apr 23', employee: 3600, employer: 3600, interest: 610, total: 7810 },
    { month: 'May 23', employee: 3600, employer: 3600, interest: 625, total: 7825 },
    { month: 'Jun 23', employee: 3600, employer: 3600, interest: 640, total: 7840 },
    { month: 'Jul 23', employee: 3600, employer: 3600, interest: 655, total: 7855 },
    { month: 'Aug 23', employee: 3600, employer: 3600, interest: 670, total: 7870 },
    { month: 'Sep 23', employee: 3600, employer: 3600, interest: 685, total: 7885 },
    { month: 'Oct 23', employee: 3600, employer: 3600, interest: 700, total: 7900 },
    { month: 'Nov 23', employee: 3600, employer: 3600, interest: 715, total: 7915 },
    { month: 'Dec 23', employee: 3600, employer: 3600, interest: 730, total: 7930 },
    { month: 'Jan 24', employee: 3600, employer: 3600, interest: 745, total: 7945 }
  ];

  // Balance growth over time
  const balanceGrowth = [
    { year: '2018', balance: 45000 },
    { year: '2019', balance: 125000 },
    { year: '2020', balance: 230000 },
    { year: '2021', balance: 350000 },
    { year: '2022', balance: 485000 },
    { year: '2023', balance: 635000 },
    { year: '2024', balance: epfData.currentBalance }
  ];

  // Retirement projections
  const projectionData = [];
  let currentAge = 28; // Mock current age
  let currentBalance = epfData.currentBalance;
  const retirementAge = 58;
  const monthlyContrib = epfData.monthlyContribution * 2; // Employee + Employer
  
  for (let age = currentAge; age <= retirementAge; age++) {
    if (age === currentAge) {
      projectionData.push({ age, balance: currentBalance });
    } else {
      // Compound growth calculation
      currentBalance = currentBalance * (1 + epfData.currentRate / 100) + (monthlyContrib * 12);
      projectionData.push({ age, balance: Math.round(currentBalance) });
    }
  }

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;
  const formatDate = (dateStr: string) => new Date(dateStr).toLocaleDateString('en-IN');

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <PiggyBank className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">EPF Portfolio</h1>
            <p className="text-muted-foreground">Track your Employee Provident Fund contributions and growth</p>
          </div>
        </div>
        <Button onClick={refreshEPFData} disabled={loading} variant="outline">
          {loading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="mr-2 h-4 w-4" />
          )}
          Refresh Data
        </Button>
      </div>

      {/* Account Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <PiggyBank className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(epfData.currentBalance)}</div>
            <p className="text-xs text-muted-foreground">
              Current EPF balance
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Contribution</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(epfData.monthlyContribution * 2)}</div>
            <p className="text-xs text-success">
              ₹{epfData.monthlyContribution.toLocaleString()} each (you + employer)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Interest Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{epfData.currentRate}%</div>
            <p className="text-xs text-muted-foreground">
              Current PF interest rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Years to Retirement</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">30</div>
            <p className="text-xs text-muted-foreground">
              At age 58 (standard retirement)
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Account Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="w-5 h-5" />
            <span>Account Information</span>
          </CardTitle>
          <CardDescription>Your EPF account details and status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-muted-foreground">Account Number</p>
              <p className="font-mono text-sm font-medium">{epfData.accountNumber}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Member Since</p>
              <p className="font-medium">{formatDate(epfData.memberSince)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Status</p>
              <Badge variant="default">{epfData.status}</Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Basic Salary</p>
              <p className="font-medium">{formatCurrency(epfData.basicSalary)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Contribution Rate</p>
              <p className="font-medium">{epfData.contributionRate}%</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Last Contribution</p>
              <p className="font-medium">{formatDate(epfData.lastContribution)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="contributions">Contributions</TabsTrigger>
          <TabsTrigger value="growth">Growth</TabsTrigger>
          <TabsTrigger value="projections">Projections</TabsTrigger>
          <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Balance Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>Balance Breakdown</CardTitle>
                <CardDescription>Contribution and fund allocation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <User className="w-4 h-4 text-blue-500" />
                      <span className="text-sm font-medium">Your Contributions</span>
                    </div>
                    <span className="text-sm">{formatCurrency(epfData.employeeContribution)}</span>
                  </div>
                  <Progress value={(epfData.employeeContribution / epfData.currentBalance) * 100} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Building className="w-4 h-4 text-green-500" />
                      <span className="text-sm font-medium">Employer Contributions</span>
                    </div>
                    <span className="text-sm">{formatCurrency(epfData.employerContribution)}</span>
                  </div>
                  <Progress value={(epfData.employerContribution / epfData.currentBalance) * 100} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Gift className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm font-medium">Interest Earned</span>
                    </div>
                    <span className="text-sm">{formatCurrency(epfData.interestEarned)}</span>
                  </div>
                  <Progress value={(epfData.interestEarned / epfData.currentBalance) * 100} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Fund Split */}
            <Card>
              <CardHeader>
                <CardTitle>Fund Allocation</CardTitle>
                <CardDescription>EPF and Pension fund split</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <p className="text-sm text-muted-foreground">EPF Account</p>
                    <p className="text-xl font-bold text-blue-600">{formatCurrency(epfData.epfFund)}</p>
                    <p className="text-xs text-muted-foreground">3.67% of salary</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <p className="text-sm text-muted-foreground">Pension Fund</p>
                    <p className="text-xl font-bold text-green-600">{formatCurrency(epfData.pensionFund)}</p>
                    <p className="text-xs text-muted-foreground">8.33% of salary</p>
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-muted rounded-lg">
                  <p className="text-sm">
                    <strong>Note:</strong> Your employer's 12% contribution is split between EPF (3.67%) and Pension Fund (8.33%).
                    Your entire 12% goes to EPF.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="contributions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Contribution History</CardTitle>
              <CardDescription>Last 12 months contribution breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={contributionHistory}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="month" 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`}
                    />
                    <Tooltip 
                      formatter={(value: number, name: string) => [`₹${value.toLocaleString('en-IN')}`, name]}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                    />
                    <Bar dataKey="employee" stackId="a" fill="#3B82F6" name="Employee" />
                    <Bar dataKey="employer" stackId="a" fill="#10B981" name="Employer" />
                    <Bar dataKey="interest" stackId="a" fill="#F59E0B" name="Interest" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Annual Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Your Contributions (2024)</span>
                    <span className="font-medium">₹43,200</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Employer Contributions (2024)</span>
                    <span className="font-medium">₹43,200</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Interest Credited (2023)</span>
                    <span className="font-medium text-success">₹8,100</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t">
                    <span className="font-medium">Total Growth (YTD)</span>
                    <span className="font-bold text-success">₹94,500</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Contribution Rate Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Employee Contribution</span>
                      <span className="text-sm font-medium">12%</span>
                    </div>
                    <Progress value={12} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Employer Contribution</span>
                      <span className="text-sm font-medium">12%</span>
                    </div>
                    <Progress value={12} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">VPF (Optional)</span>
                      <span className="text-sm font-medium">0%</span>
                    </div>
                    <Progress value={0} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="growth" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Balance Growth Over Time</CardTitle>
              <CardDescription>Historical balance growth since joining</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={balanceGrowth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="year" 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickFormatter={(value) => `₹${(value / 100000).toFixed(0)}L`}
                    />
                    <Tooltip 
                      formatter={(value: number) => [`₹${value.toLocaleString('en-IN')}`, 'Balance']}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="balance" 
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      fill="hsl(var(--primary))"
                      fillOpacity={0.1}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projections" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calculator className="w-5 h-5" />
                <span>Retirement Projection</span>
              </CardTitle>
              <CardDescription>Projected balance at retirement (age 58)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={projectionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="age" 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickFormatter={(value) => `₹${(value / 1000000).toFixed(1)}Cr`}
                    />
                    <Tooltip 
                      formatter={(value: number) => [`₹${value.toLocaleString('en-IN')}`, 'Projected Balance']}
                      labelFormatter={(age) => `Age: ${age}`}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="balance" 
                      stroke="hsl(var(--primary))"
                      strokeWidth={3}
                      dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6, stroke: 'hsl(var(--primary))', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>At Retirement (58)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-success mb-2">
                    ₹{projectionData[projectionData.length - 1]?.balance.toLocaleString('en-IN')}
                  </div>
                  <p className="text-sm text-muted-foreground">Projected EPF balance</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Monthly Pension</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-info mb-2">₹12,500</div>
                  <p className="text-sm text-muted-foreground">Estimated EPS pension</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Total Corpus</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">₹2.8 Cr</div>
                  <p className="text-sm text-muted-foreground">EPF + Pension value</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="withdrawals" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Partial Withdrawal Rules</CardTitle>
                <CardDescription>When you can withdraw from your EPF</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <h4 className="font-medium text-blue-800 dark:text-blue-200">Medical Emergency</h4>
                    <p className="text-sm text-blue-600 dark:text-blue-300">Up to 6 months of basic salary + DA</p>
                  </div>
                  <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                    <h4 className="font-medium text-green-800 dark:text-green-200">Home Purchase</h4>
                    <p className="text-sm text-green-600 dark:text-green-300">After 5 years of service</p>
                  </div>
                  <div className="p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                    <h4 className="font-medium text-yellow-800 dark:text-yellow-200">Education</h4>
                    <p className="text-sm text-yellow-600 dark:text-yellow-300">For higher education expenses</p>
                  </div>
                  <div className="p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                    <h4 className="font-medium text-purple-800 dark:text-purple-200">Marriage</h4>
                    <p className="text-sm text-purple-600 dark:text-purple-300">After 7 years of service</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tax Implications</CardTitle>
                <CardDescription>Tax rules for EPF withdrawals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-success">Tax-Free Withdrawal</h4>
                    <ul className="text-sm text-muted-foreground mt-2 space-y-1">
                      <li>• After 5 years of continuous service</li>
                      <li>• Employer contribution is tax-free</li>
                      <li>• Interest on contributions is tax-free</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-warning">Taxable Withdrawal</h4>
                    <ul className="text-sm text-muted-foreground mt-2 space-y-1">
                      <li>• Before 5 years of service</li>
                      <li>• Interest portion may be taxable</li>
                      <li>• TDS applicable on premature withdrawal</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Online Services</CardTitle>
              <CardDescription>Available EPF services and portals</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                  <Banknote className="w-6 h-6" />
                  <span className="text-sm">Balance Check</span>
                </Button>
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                  <FileText className="w-6 h-6" />
                  <span className="text-sm">Passbook</span>
                </Button>
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                  <User className="w-6 h-6" />
                  <span className="text-sm">Claim Status</span>
                </Button>
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                  <Building className="w-6 h-6" />
                  <span className="text-sm">Transfer</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Raw Data */}
      {state.data.epf_status && (
        <Card>
          <CardHeader>
            <CardTitle>Raw EPF Data</CardTitle>
            <CardDescription>Detailed information from your EPF account</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="text-sm bg-muted p-4 rounded-md overflow-auto max-h-64">
              {state.data.epf_status}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
