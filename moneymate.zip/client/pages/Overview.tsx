import React, { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { callMoneyMate, extractSummary, parseNetWorth, parseCreditScore } from '@/lib/moneymate-api';
import { AssetPieChart, CreditGauge } from '@/components/charts';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { DEFAULT_TZ } from '@shared/moneymate';

export default function Overview() {
  const { state, dispatch } = useDashboard();
  const [loading, setLoading] = useState(false);

  const netWorthData = parseNetWorth(state.data.net_worth || '');
  const creditScore = parseCreditScore(state.data.credit_health || '');

  const refreshData = async (goal: string) => {
    setLoading(true);
    try {
      const response = await callMoneyMate({
        phone: state.phone,
        consent: true,
        goal,
        mode: 'data_only',
        tz: DEFAULT_TZ
      }, state.sid);
      
      const summary = extractSummary(response);
      dispatch({ type: 'SET_DATA', payload: { [goal]: summary } });
    } catch (error) {
      console.error('Failed to refresh data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;

  const getNetWorthTrend = () => {
    // This would typically come from historical data
    // For now, we'll simulate based on current value
    const trend = Math.random() > 0.5 ? 'up' : 'down';
    const percentage = Math.floor(Math.random() * 15) + 1;
    return { trend, percentage };
  };

  const trend = getNetWorthTrend();

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Financial Overview</h1>
          <p className="text-muted-foreground">Your complete financial picture at a glance</p>
        </div>
        <Button 
          onClick={() => refreshData('net_worth')} 
          disabled={loading}
          variant="outline"
        >
          {loading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="mr-2 h-4 w-4" />
          )}
          Refresh
        </Button>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Net Worth</CardTitle>
            {trend.trend === 'up' ? (
              <TrendingUp className="h-4 w-4 text-success" />
            ) : trend.trend === 'down' ? (
              <TrendingDown className="h-4 w-4 text-destructive" />
            ) : (
              <Minus className="h-4 w-4 text-muted-foreground" />
            )}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {netWorthData.total ? formatCurrency(netWorthData.total) : '—'}
            </div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              <span>
                {trend.trend === 'up' ? '+' : trend.trend === 'down' ? '-' : ''}
                {trend.percentage}% from last month
              </span>
              <Badge variant={trend.trend === 'up' ? 'default' : trend.trend === 'down' ? 'destructive' : 'secondary'}>
                {trend.trend === 'up' ? 'Growth' : trend.trend === 'down' ? 'Decline' : 'Stable'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Credit Score</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {creditScore || '—'}
            </div>
            <p className="text-xs text-muted-foreground">
              {creditScore ? (
                creditScore >= 750 ? 'Excellent credit health' :
                creditScore >= 650 ? 'Good credit standing' :
                'Needs improvement'
              ) : 'No data available'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Asset Count</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Object.keys(netWorthData.assets).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Diversified portfolio
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <Tabs defaultValue="assets" className="space-y-4">
        <TabsList>
          <TabsTrigger value="assets">Asset Allocation</TabsTrigger>
          <TabsTrigger value="credit">Credit Health</TabsTrigger>
          <TabsTrigger value="summary">Data Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="assets" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {Object.keys(netWorthData.assets).length > 0 ? (
              <AssetPieChart data={netWorthData.assets} />
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Asset Allocation</CardTitle>
                  <CardDescription>No asset data available</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <p>No asset data found. Please refresh or check your data source.</p>
                    <Button 
                      onClick={() => refreshData('net_worth')} 
                      variant="outline" 
                      className="mt-4"
                    >
                      Refresh Data
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Manage your finances</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => refreshData('spend_summary')}
                >
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Update Spending Data
                </Button>
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => refreshData('mf_activity')}
                >
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Refresh Mutual Funds
                </Button>
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => refreshData('epf_status')}
                >
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Check EPF Status
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="credit" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {creditScore ? (
              <CreditGauge score={creditScore} />
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Credit Score</CardTitle>
                  <CardDescription>No credit data available</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <p>No credit score data found.</p>
                    <Button 
                      onClick={() => refreshData('credit_health')} 
                      variant="outline" 
                      className="mt-4"
                    >
                      Load Credit Data
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Credit Tips</CardTitle>
                <CardDescription>Improve your credit health</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Pay all bills on time</li>
                  <li>• Keep credit utilization below 30%</li>
                  <li>• Don't close old credit accounts</li>
                  <li>• Monitor your credit report regularly</li>
                  <li>• Limit new credit applications</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="summary" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Raw Data Summary</CardTitle>
              <CardDescription>Detailed financial information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Net Worth Data:</h4>
                  <pre className="text-sm bg-muted p-4 rounded-md overflow-auto max-h-48">
                    {state.data.net_worth || 'No net worth data available'}
                  </pre>
                </div>
                
                {state.data.credit_health && (
                  <div>
                    <h4 className="font-semibold mb-2">Credit Health Data:</h4>
                    <pre className="text-sm bg-muted p-4 rounded-md overflow-auto max-h-48">
                      {state.data.credit_health}
                    </pre>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
