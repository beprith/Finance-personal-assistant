import axios from 'axios';
import { 
  AuthPayload, 
  ApiResponse, 
  NetWorthData, 
  FLOW_URL, 
  SUMMARY_REGEX, 
  NET_WORTH_REGEX, 
  CREDIT_SCORE_REGEX 
} from '@shared/moneymate';

const API_KEY = import.meta.env.VITE_LANGFLOW_API_KEY;

if (!API_KEY) {
  console.error("VITE_LANGFLOW_API_KEY not set in environment");
}

function createEnvPayload(obj: Record<string, any>, sessionId: string) {
  return {
    output_type: "chat",
    input_type: "chat",
    input_value: JSON.stringify(obj),
    session_id: sessionId
  };
}

export async function callMoneyMate(payload: AuthPayload, sessionId: string): Promise<ApiResponse> {
  if (!API_KEY) {
    throw new Error('VITE_LANGFLOW_API_KEY environment variable is not set');
  }

  const headers = {
    "Content-Type": "application/json",
    "x-api-key": API_KEY
  };

  const requestPayload = createEnvPayload(payload, sessionId);

  try {
    const response = await axios.post(
      FLOW_URL,
      requestPayload,
      { headers, timeout: 120000 }
    );

    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.code === 'ERR_NETWORK') {
        throw new Error('Network error: Unable to connect to MoneyMate API. Please check if the API is running.');
      } else if (error.response?.status === 401) {
        throw new Error('Authentication failed: Invalid API key');
      } else if (error.response?.status === 404) {
        throw new Error('API endpoint not found. Please check the FLOW_URL configuration.');
      } else {
        throw new Error(`API Error: ${error.response?.status} - ${error.response?.data?.message || error.message}`);
      }
    }
    throw error;
  }
}

export function extractText(response: ApiResponse): string {
  const out: string[] = [];

  // Match Python: if (outs := resp.get("outputs")):
  if (response.outputs) {
    for (const o of response.outputs) {
      for (const inner of o.outputs || []) {
        const res = inner.results || {};
        if (res.result) {
          out.push(res.result);
        }
        const msg = res.message || {};
        if (typeof msg === 'object') {
          if (msg.data?.text) {
            out.push(msg.data.text);
          }
          if (msg.text) {
            out.push(msg.text);
          }
        }
      }
    }
  }

  // Match Python: if (op := resp.get("output")) and op.get("choices"):
  if (response.output?.choices) {
    const c = response.output.choices[0];
    if (c.text) {
      out.push(c.text);
    }
    if (typeof c.message === 'object' && c.message?.content) {
      out.push(c.message.content);
    }
  }

  // Match Python: return "\n".join([t for t in out if t])
  return out.filter(t => t).join('\n');
}

export function extractSummary(response: ApiResponse): string {
  const rawText = extractText(response);
  const match = SUMMARY_REGEX.exec(rawText);
  return match ? match[1].trim() : rawText.trim();
}

export function parseNetWorth(summary: string): NetWorthData {
  const totalMatch = NET_WORTH_REGEX.exec(summary);
  const total = totalMatch ? parseInt(totalMatch[1].replace(/,/g, '')) : null;

  const assets: Record<string, number> = {};
  
  for (const line of summary.split('\n')) {
    if (line.includes(':') && line.includes('₹')) {
      const [label, amount] = line.split(':', 2);
      const numericAmount = amount.replace(/[^\d]/g, '');
      if (numericAmount) {
        const cleanLabel = label.replace(/^[*•\s]+/, '').trim();
        assets[cleanLabel] = parseInt(numericAmount);
      }
    }
  }

  return { total, assets };
}

export function parseCreditScore(summary: string): number | null {
  console.log('🔍 Parsing credit score from summary:', summary);

  // Try multiple patterns to catch different credit score formats
  const patterns = [
    /Credit Score:\s*([0-9]{3})/i,
    /CIBIL Score:\s*([0-9]{3})/i,
    /Score:\s*([0-9]{3})/i,
    /credit.*?score.*?([0-9]{3})/i,
    /([0-9]{3}).*?credit.*?score/i,
    /\b([0-9]{3})\b/g  // Any 3-digit number as fallback
  ];

  for (const pattern of patterns) {
    const match = pattern.exec(summary);
    if (match) {
      const score = parseInt(match[1]);
      // Credit scores are typically between 300-900
      if (score >= 300 && score <= 900) {
        console.log('✅ Found credit score:', score, 'with pattern:', pattern);
        return score;
      }
    }
  }

  console.log('❌ No credit score found in summary');
  return null;
}

export function projectSIP(netWorth: number, extraSip: number, years: number = 5, rate: number = 0.08): number {
  let future = netWorth;
  const yearly = extraSip * 12;
  
  for (let i = 0; i < years; i++) {
    future = (future + yearly) * (1 + rate);
  }
  
  return Math.round(future);
}
