import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { DashboardState } from '@shared/moneymate';
import { v4 as uuidv4 } from 'uuid';

interface DashboardAction {
  type: 'SET_AUTH' | 'SET_PHONE' | 'SET_DATA' | 'CLEAR_DATA' | 'TOGGLE_DARK' | 'SET_DARK';
  payload?: any;
}

const initialState: DashboardState = {
  sid: `sess_${uuidv4()}`,
  auth: false,
  phone: '',
  data: {},
  dark: false
};

function dashboardReducer(state: DashboardState, action: DashboardAction): DashboardState {
  switch (action.type) {
    case 'SET_AUTH':
      return { ...state, auth: action.payload };
    case 'SET_PHONE':
      return { ...state, phone: action.payload };
    case 'SET_DATA':
      return { ...state, data: { ...state.data, ...action.payload } };
    case 'CLEAR_DATA':
      return { ...state, data: {} };
    case 'TOGGLE_DARK':
      return { ...state, dark: !state.dark };
    case 'SET_DARK':
      return { ...state, dark: action.payload };
    default:
      return state;
  }
}

const DashboardContext = createContext<{
  state: DashboardState;
  dispatch: React.Dispatch<DashboardAction>;
} | null>(null);

export function DashboardProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(dashboardReducer, initialState);

  // Load saved state from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('moneymate-dashboard');
    if (saved) {
      try {
        const parsedState = JSON.parse(saved);
        dispatch({ type: 'SET_PHONE', payload: parsedState.phone || '' });
        dispatch({ type: 'SET_DARK', payload: parsedState.dark || false });
      } catch (e) {
        console.error('Failed to load saved state:', e);
      }
    }
  }, []);

  // Save state to localStorage
  useEffect(() => {
    localStorage.setItem('moneymate-dashboard', JSON.stringify({
      phone: state.phone,
      dark: state.dark
    }));
  }, [state.phone, state.dark]);

  // Apply dark mode class to document
  useEffect(() => {
    if (state.dark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.dark]);

  return (
    <DashboardContext.Provider value={{ state, dispatch }}>
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  const context = useContext(DashboardContext);
  if (!context) {
    throw new Error('useDashboard must be used within a DashboardProvider');
  }
  return context;
}
