import { useState } from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { callMoneyMate, extractSummary } from '@/lib/moneymate-api';
import { PHONE_REGEX, DEFAULT_TZ } from '@shared/moneymate';

export function useAuth() {
  const { state, dispatch } = useDashboard();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validatePhone = (phone: string): boolean => {
    return PHONE_REGEX.test(phone.trim());
  };

  const authenticate = async (phone: string) => {
    setLoading(true);
    setError(null);

    try {
      if (!validatePhone(phone)) {
        throw new Error('Invalid phone number format');
      }

      // Clear data if phone changed
      if (phone.trim() !== state.phone) {
        dispatch({ type: 'CLEAR_DATA' });
      }

      const payload = {
        phone: phone.trim(),
        consent: true,
        goal: 'net_worth',
        mode: 'data_only',
        tz: DEFAULT_TZ
      };

      const response = await callMoneyMate(payload, state.sid);
      const summary = extractSummary(response);

      dispatch({ type: 'SET_AUTH', payload: true });
      dispatch({ type: 'SET_PHONE', payload: phone.trim() });
      dispatch({ type: 'SET_DATA', payload: { net_worth: summary } });

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
      dispatch({ type: 'SET_AUTH', payload: false });
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    dispatch({ type: 'SET_AUTH', payload: false });
    dispatch({ type: 'SET_PHONE', payload: '' });
    dispatch({ type: 'CLEAR_DATA' });
  };

  return {
    isAuthenticated: state.auth,
    phone: state.phone,
    loading,
    error,
    authenticate,
    logout,
    validatePhone
  };
}
