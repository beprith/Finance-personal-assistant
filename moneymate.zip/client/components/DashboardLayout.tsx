import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useDashboard } from '@/lib/dashboard-context';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { 
  BarChart3, 
  CreditCard, 
  DollarSign, 
  FileText, 
  Home, 
  LogOut, 
  MessageCircle, 
  Moon,
  PiggyBank,
  Sliders,
  Sun,
  TrendingUp,
  Wallet
} from 'lucide-react';

const navigation = [
  { name: 'Overview', href: '/', icon: Home },
  { name: 'Spend', href: '/spend', icon: Wallet },
  { name: 'Credit', href: '/credit', icon: CreditCard },
  { name: 'EPF', href: '/epf', icon: PiggyBank },
  { name: 'Mutual Funds', href: '/mutual-funds', icon: TrendingUp },
  { name: 'Chat', href: '/chat', icon: MessageCircle },
  { name: 'What-if', href: '/what-if', icon: Sliders },
  { name: 'Download Report', href: '/download', icon: FileText }
];

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { state, dispatch } = useDashboard();
  const { logout } = useAuth();
  const location = useLocation();

  const toggleDarkMode = () => {
    dispatch({ type: 'TOGGLE_DARK' });
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-sidebar border-r border-sidebar-border">
          {/* Logo */}
          <div className="flex items-center flex-shrink-0 px-4">
            <DollarSign className="w-8 h-8 text-sidebar-primary" />
            <span className="ml-2 text-xl font-bold text-sidebar-foreground">MoneyMate</span>
          </div>

          {/* Navigation */}
          <div className="mt-8 flex-grow flex flex-col">
            <nav className="flex-1 px-2 space-y-1">
              {navigation.map((item) => {
                const isActive = location.pathname === item.href;
                const Icon = item.icon;
                
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={cn(
                      'group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors',
                      isActive
                        ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                        : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    )}
                  >
                    <Icon
                      className={cn(
                        'mr-3 h-5 w-5 flex-shrink-0',
                        isActive ? 'text-sidebar-primary' : 'text-sidebar-foreground group-hover:text-sidebar-primary'
                      )}
                    />
                    {item.name}
                  </Link>
                );
              })}
            </nav>

            {/* Settings */}
            <div className="px-2 py-4 space-y-4 border-t border-sidebar-border">
              <div className="flex items-center justify-between px-2">
                <div className="flex items-center space-x-2">
                  {state.dark ? (
                    <Moon className="h-4 w-4 text-sidebar-foreground" />
                  ) : (
                    <Sun className="h-4 w-4 text-sidebar-foreground" />
                  )}
                  <span className="text-sm text-sidebar-foreground">Dark Mode</span>
                </div>
                <Switch
                  checked={state.dark}
                  onCheckedChange={toggleDarkMode}
                />
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="w-full justify-start text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent"
              >
                <LogOut className="mr-3 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Mobile header */}
        <div className="md:hidden flex items-center justify-between p-4 bg-sidebar border-b border-sidebar-border">
          <div className="flex items-center">
            <DollarSign className="w-6 h-6 text-sidebar-primary" />
            <span className="ml-2 text-lg font-bold text-sidebar-foreground">MoneyMate</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              checked={state.dark}
              onCheckedChange={toggleDarkMode}
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          {children}
        </main>
      </div>
    </div>
  );
}
