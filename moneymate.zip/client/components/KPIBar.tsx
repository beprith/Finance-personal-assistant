import React from 'react';
import { useDashboard } from '@/lib/dashboard-context';
import { parseNetWorth, parseCreditScore } from '@/lib/moneymate-api';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { TrendingUp, CreditCard, AlertTriangle, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';

export function KPIBar() {
  const { state } = useDashboard();

  const netWorthData = parseNetWorth(state.data.net_worth || '');
  const creditScore = parseCreditScore(state.data.credit_health || '');

  console.log('🏦 KPI Bar - Credit Health Data:', state.data.credit_health);
  console.log('🎯 KPI Bar - Parsed Credit Score:', creditScore);

  // Manual fallback for credit score if parsing failed
  const manualCreditScore = React.useMemo(() => {
    if (creditScore || !state.data.credit_health) return null;

    const allNumbers = state.data.credit_health.match(/\b\d{3}\b/g);
    if (allNumbers) {
      const validScore = allNumbers
        .map(num => parseInt(num))
        .find(num => num >= 300 && num <= 900);
      return validScore || null;
    }
    return null;
  }, [creditScore, state.data.credit_health]);

  const displayCreditScore = creditScore || manualCreditScore;
  
  const formatCurrency = (amount: number | null) => {
    if (amount === null) return '—';
    return `₹${amount.toLocaleString('en-IN')}`;
  };

  const getCreditScoreColor = (score: number | null) => {
    if (!score) return 'text-muted-foreground';
    if (score >= 750) return 'text-success';
    if (score >= 650) return 'text-warning';
    return 'text-destructive';
  };

  const getCreditScoreIcon = (score: number | null) => {
    if (!score) return null;
    if (score >= 650) return <TrendingUp className="w-4 h-4" />;
    return <TrendingDown className="w-4 h-4" />;
  };

  return (
    <div className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border/40">
      <div className="container mx-auto px-4 py-4">
        {/* KPI Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Net Worth</p>
                <p className="text-2xl font-bold text-foreground">
                  {formatCurrency(netWorthData.total)}
                </p>
              </div>
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-primary" />
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Credit Score</p>
                <div className="flex items-center space-x-2">
                  <p className={cn("text-2xl font-bold", getCreditScoreColor(displayCreditScore))}>
                    {displayCreditScore || '—'}
                  </p>
                  {getCreditScoreIcon(displayCreditScore)}
                </div>
              </div>
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-primary" />
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="text-lg font-semibold text-success">Active</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-success animate-pulse"></div>
              </div>
            </div>
          </Card>
        </div>

        {/* Alerts */}
        {displayCreditScore && displayCreditScore < 650 && (
          <Alert variant="destructive" className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Credit score below healthy threshold (650). Consider reviewing your credit report.
            </AlertDescription>
          </Alert>
        )}

        {netWorthData.total && netWorthData.total < 100000 && (
          <Alert className="mb-4">
            <TrendingUp className="h-4 w-4" />
            <AlertDescription>
              Build your emergency fund to reach ₹1,00,000 for better financial security.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
}
