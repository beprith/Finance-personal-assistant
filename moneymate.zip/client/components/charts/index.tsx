import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

// Color palette for charts
const COLORS = {
  primary: 'hsl(var(--primary))',
  success: 'hsl(var(--success))', 
  warning: 'hsl(var(--warning))',
  info: 'hsl(var(--info))',
  muted: 'hsl(var(--muted))',
  chart: [
    '#10B981', // Emerald
    '#3B82F6', // Blue
    '#F59E0B', // Amber
    '#EF4444', // Red
    '#8B5CF6', // Violet
    '#06B6D4', // Cyan
    '#84CC16', // Lime
    '#F97316'  // Orange
  ]
};

interface AssetPieChartProps {
  data: { [key: string]: number };
  title?: string;
}

export function AssetPieChart({ data, title = "Asset Allocation" }: AssetPieChartProps) {
  const chartData = Object.entries(data).map(([name, value], index) => ({
    name,
    value,
    color: COLORS.chart[index % COLORS.chart.length]
  }));

  const formatValue = (value: number) => `₹${value.toLocaleString('en-IN')}`;

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>Breakdown of your assets</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                outerRadius={100}
                dataKey="value"
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => [formatValue(value), 'Amount']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

interface CreditGaugeProps {
  score: number;
  title?: string;
}

export function CreditGauge({ score, title = "Credit Score" }: CreditGaugeProps) {
  const getScoreColor = () => {
    if (score >= 750) return COLORS.success;
    if (score >= 650) return COLORS.warning;
    return '#EF4444';
  };

  const getScoreText = () => {
    if (score >= 750) return 'Excellent';
    if (score >= 700) return 'Good';
    if (score >= 650) return 'Fair';
    return 'Poor';
  };

  // Create gauge data for visualization
  const gaugeData = [
    { name: 'Poor', value: 250, color: '#EF4444' },
    { name: 'Fair', value: 100, color: '#F59E0B' },
    { name: 'Good', value: 100, color: '#3B82F6' },
    { name: 'Excellent', value: 150, color: '#10B981' }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>Your creditworthiness rating</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center space-y-4">
          <div className="relative w-40 h-40">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={gaugeData}
                  cx="50%"
                  cy="80%"
                  startAngle={180}
                  endAngle={0}
                  innerRadius={60}
                  outerRadius={80}
                  dataKey="value"
                >
                  {gaugeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            
            {/* Score display */}
            <div className="absolute inset-0 flex flex-col items-center justify-center mt-8">
              <div className="text-3xl font-bold" style={{ color: getScoreColor() }}>
                {score}
              </div>
              <div className="text-sm text-muted-foreground">
                {getScoreText()}
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Range: 300-900 • Your score: <span style={{ color: getScoreColor() }}>{score}</span>
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface SpendLineChartProps {
  data: Array<{ month: string; amount: number }>;
  title?: string;
}

export function SpendLineChart({ data, title = "Monthly Spending Trend" }: SpendLineChartProps) {
  const formatValue = (value: number) => `₹${value.toLocaleString('en-IN')}`;

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>Your spending pattern over time</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip 
                formatter={(value: number) => [formatValue(value), 'Spent']}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="amount" 
                stroke={COLORS.primary}
                strokeWidth={3}
                dot={{ fill: COLORS.primary, strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: COLORS.primary, strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

interface CategoryHeatmapProps {
  data: Array<{ category: string; amount: number; percentage: number }>;
  title?: string;
}

export function CategoryHeatmap({ data, title = "Spending by Category" }: CategoryHeatmapProps) {
  const sortedData = [...data].sort((a, b) => b.amount - a.amount);
  const maxAmount = Math.max(...data.map(d => d.amount));

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>Where your money goes</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sortedData.map((item, index) => {
            const intensity = item.amount / maxAmount;
            const barColor = `rgba(16, 185, 129, ${0.1 + intensity * 0.8})`;
            
            return (
              <div key={item.category} className="flex items-center space-x-4">
                <div className="w-24 text-sm text-muted-foreground truncate">
                  {item.category}
                </div>
                <div className="flex-1 relative">
                  <div 
                    className="h-8 rounded-md flex items-center px-3"
                    style={{ backgroundColor: barColor }}
                  >
                    <span className="text-sm font-medium text-foreground">
                      ₹{item.amount.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
                <div className="w-12 text-sm text-muted-foreground text-right">
                  {item.percentage.toFixed(1)}%
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

interface ProjectionChartProps {
  currentValue: number;
  projectedValue: number;
  years: number;
  extraSip: number;
  title?: string;
}

export function ProjectionChart({ 
  currentValue, 
  projectedValue, 
  years, 
  extraSip,
  title = "SIP Projection"
}: ProjectionChartProps) {
  const yearlyData = [];
  let value = currentValue;
  const yearlyInvestment = extraSip * 12;
  
  for (let year = 0; year <= years; year++) {
    yearlyData.push({
      year: year === 0 ? 'Now' : `Year ${year}`,
      value: Math.round(value)
    });
    
    if (year < years) {
      value = (value + yearlyInvestment) * 1.08; // 8% CAGR
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>
          Growth with ₹{extraSip.toLocaleString('en-IN')}/month additional SIP
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={yearlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="year"
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => `₹${(value / 100000).toFixed(0)}L`}
              />
              <Tooltip 
                formatter={(value: number) => [`₹${value.toLocaleString('en-IN')}`, 'Net Worth']}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px'
                }}
              />
              <Bar 
                dataKey="value" 
                fill={COLORS.primary}
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
