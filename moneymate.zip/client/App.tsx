import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { DashboardProvider } from '@/lib/dashboard-context';
import { useAuth } from '@/hooks/use-auth';
import { AuthPage } from '@/components/AuthPage';
import { DashboardLayout } from '@/components/DashboardLayout';
import { KPIBar } from '@/components/KPIBar';

// Pages
import Overview from '@/pages/Overview';
import Spend from '@/pages/Spend';
import Credit from '@/pages/Credit';
import EPF from '@/pages/EPF';
import MutualFunds from '@/pages/MutualFunds';
import Chat from '@/pages/Chat';
import WhatIf from '@/pages/WhatIf';
import Download from '@/pages/Download';
import NotFound from '@/pages/NotFound';

function AppContent() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  return (
    <DashboardLayout>
      <KPIBar />
      <Routes>
        <Route path="/" element={<Overview />} />
        <Route path="/spend" element={<Spend />} />
        <Route path="/credit" element={<Credit />} />
        <Route path="/epf" element={<EPF />} />
        <Route path="/mutual-funds" element={<MutualFunds />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/what-if" element={<WhatIf />} />
        <Route path="/download" element={<Download />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </DashboardLayout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <DashboardProvider>
        <div className="min-h-screen bg-background">
          <AppContent />
        </div>
      </DashboardProvider>
    </BrowserRouter>
  );
}
